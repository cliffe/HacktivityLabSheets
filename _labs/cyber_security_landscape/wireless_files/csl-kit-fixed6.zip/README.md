# CSL Wireless Security lab: staff setup kit

Private staff material for the in-person Wi-Fi lab whose student sheet is
`HacktivityLabSheets/_labs/cyber_security_landscape/8_wireless_security.md`
(branch `wifi_update` on the `thomashaw` fork). It is kept here, not in the
public sheets repo, because it explains how each task is solved.

Nothing in this directory has been run yet. Every step is marked with what
to check during the in-person test (section 8).

```
README.md               this guide
staff_server/
  Caddyfile             the cafe's web server (192.168.75.10)
  Caddyfile.attacker    the "attacker's server" for the stretch task (192.168.75.11)
  sites/                static sites; copy to C:\csl-lab\sites on the staff PC
```

## 1. The lab network

```
                 2.4 GHz only, channel 6, open SSID "CSL-Cafe"
   [Archer router 192.168.75.1] ------ ethernet (USB adapter) ------ [Staff PC]
          ^        DHCP .100-.199, DNS = 192.168.75.10               192.168.75.10  DNS (Technitium) + Caddy
          |                                                          192.168.75.11  Caddy (attacker server)
          | Wi-Fi (Pineapple client radio, wlan2)
   [Pineapple] <---- USB-C ----> [Attacker PC]   (student image, Wireshark, ssh)
          ^
          | Wi-Fi (evil twin "CSL-Cafe")
   [Victim PC + Archer dongle]   (student image, NETWORK CABLE UNPLUGGED)
```

There is no internet on the cafe network. The flow during an attack is
victim, then Pineapple open AP, then Pineapple NAT, then the Pineapple's
client radio, then the router, then the staff PC. The Pineapple's own DNS
(dnsmasq) forwards to whatever DNS the router's DHCP gives it
(192.168.75.10), so the `csl.internal` names resolve through the Pineapple
too, and the stretch task can override them there.

Why the victim's cable must be unplugged: with both wired and Wi-Fi up,
Windows sends traffic over the lower-metric wired route, so nothing crosses
the air. The sheet tells students this; check it in the test.

## 2. Router (one per room)

On the Archer's admin page:

- **Change the admin password.** The old ones (`archer01`/`archer02`) are in
  the original .docx sheets, which are on a public branch.
- Operation mode: router. LAN IP `192.168.75.1/24` (the second room's router
  is `192.168.75.254/24`, as on its sticker; either works, and
  `Start-StaffLab.ps1` checks both). WAN unplugged. Keep the router's own
  address outside the DHCP pool and away from `.10` and `.11`.
- Wireless: turn **Smart Connect off**, **disable the 5 GHz radio** (or give
  it a different SSID). The Mark VII only has 2.4 GHz radios; with Smart
  Connect on, dual-band dongles sit on 5 GHz where the Pineapple can't see
  them, which is the most likely cause of past "it takes forever / it falls
  flat" sessions.
- 2.4 GHz: SSID `CSL-Cafe`, security **None**, **fixed channel** (6),
  **channel width 20 MHz** (not Auto or 40 MHz), WPS off, Hide SSID off.
  Use only 1, 6 or 11: they are the only 2.4 GHz channels that don't overlap,
  the university's access points already use all three, and a channel in
  between (2-5, 7-10, 12, 13) overlaps two of them and gets interference from
  both. Channel 6 for the router fits the Pineapple plan in section 7a (two
  teams on 1, two on 11). Turn the guest network off.
- DHCP server: pool `192.168.75.100` to `192.168.75.199`, **primary DNS
  `192.168.75.10` and secondary DNS `192.168.75.10` too**. Clients that fall
  back to another DNS server get no answer for `csl.internal`. A blank or
  `0.0.0.0` secondary isn't enough: the Archer then hands out its own address
  (`192.168.75.1`) as the secondary. Check from a client with
  `ipconfig /all`: the Wi-Fi adapter's DNS servers should be only
  `192.168.75.10`.
- Optional, for the tutor's deauth demo: a second SSID (or reconfigure
  briefly) with WPA2 and PMF "required", to show deauth failing.

## 3. Staff image (Windows 10)

> **Scripted.** `windows\` automates sections 3 and 4. Copy the whole
> `wireless_security` folder to each PC and run, in an elevated PowerShell
> (`powershell -ExecutionPolicy Bypass -File <script>`):
>
> | When | PC | Script |
> |---|---|---|
> | building the image | staff | `Setup-StaffImage.ps1` (Caddy, lab CA, Technitium + zones, firewall) |
> | building the image | staff | `Setup-StaffImage.ps1 -ServeCert` (serves the CA on :8080 until Ctrl+C) |
> | building the image | student | `Setup-StudentImage.ps1 -StaffHost <ip> -CertSha256 <hash>` |
> | on the day / testing | staff | `Start-StaffLab.ps1` (addresses, servers, self-tests); `-Stop` to undo |
> | last thing before capture | both | `Cleanup-BeforeImage.ps1` (`-WhatIf` first) |
>
> Both setup scripts record the local accounts when they first run;
> the cleanup removes any account (and profile), or Administrators member,
> added since, asking first. They create no accounts themselves. The steps
> below are what the scripts do, for doing it by hand or debugging.
> **None of the scripts has been run on Windows yet.**

Use a **USB-Ethernet adapter** for the router link so the PC keeps its
normal university connection on the built-in NIC. In an admin Command
Prompt (`"Ethernet 2"` is the adapter's name in `ncpa.cpl`):

```bat
netsh interface ipv4 set address name="Ethernet 2" static 192.168.75.10 255.255.255.0
netsh interface ipv4 add address name="Ethernet 2" 192.168.75.11 255.255.255.0
```

No gateway on that adapter, so the staff PC's own internet still uses the
university NIC.

### DNS: Technitium DNS Server

Windows 10 has no DNS server role; Technitium is free, runs on Windows 10
and has a web console. It needs the ASP.NET Core runtime, which its installer
downloads; behind a proxy that download fails silently and the service then
won't start ("You must install .NET" when its exe is run in a console). Turn the
proxy off before installing, or install the ASP.NET Core Runtime Hosting
Bundle by hand.

The scripts run Technitium as its `DnsService` Windows service (automatic
start, restarted by Windows if it crashes), so DNS is up after every boot.
The service runs as `NT SERVICE\DnsService` and keeps its config, zones and
logs in `C:\ProgramData\Technitium DNS Server`. Don't run `DnsService.exe`
by hand as an administrator: that copy creates files there the service can
only read, and the service then crash-loops ("Running" but no ports open,
PID changing; Application log: UnauthorizedAccessException on
`logs\<date>.log`). `Start-CslTechnitium` (used by `Setup-StaffImage.ps1` and
`Start-StaffLab.ps1`) stops such copies and gives the service account Modify
on that folder. Technitium's log is `C:\ProgramData\Technitium DNS Server\logs`.

Install it, open `http://localhost:5380`, set the
admin password, then:

- Zones, Add Zone, Primary, `csl.internal`. Add A records `intranet`,
  `shop`, `bank`, `health`, `jobs`, all `192.168.75.10`.
- Settings, Recursion: **deny recursion**. There is no internet, and refusing
  quickly is better than every Windows background lookup timing out.
- Optional, so Windows shows the cafe network as having internet access
  (and so Windows pops up the Evil Portal sign-in in Part 4): zone
  `msftconnecttest.com` with A `www` = `192.168.75.10` (Caddy answers
  `/connecttest.txt`), and zone `msftncsi.com` with A `dns` =
  `131.107.255.255`. Without this, Windows says "No internet" on the cafe
  network; everything still works, but the portal may not pop up by itself
  (the victim browses to `http://intranet.csl.internal` instead, which the
  portal intercepts).

### Web: Caddy

Caddy is a single .exe that serves HTTP and HTTPS from its own local CA,
which is why it is used here rather than IIS. Use 2.7 or later.

1. Put `caddy.exe` in `C:\csl-lab\`, copy `staff_server\Caddyfile`,
   `Caddyfile.attacker` and `sites\` there.
2. Check both configs: `caddy validate --config C:\csl-lab\Caddyfile` and the
   same for `Caddyfile.attacker`. **They have not been validated yet.**
3. Start both, each in its own console window:
   `caddy run --config C:\csl-lab\Caddyfile` and
   `caddy run --config C:\csl-lab\Caddyfile.attacker`.
4. Firewall (admin prompt):
   ```bat
   netsh advfirewall firewall add rule name="CSL lab web" dir=in action=allow protocol=TCP localport=80,443
   netsh advfirewall firewall add rule name="CSL lab DNS udp" dir=in action=allow protocol=UDP localport=53
   netsh advfirewall firewall add rule name="CSL lab DNS tcp" dir=in action=allow protocol=TCP localport=53
   ```
5. After the first start, the lab root CA is at
   `C:\csl-lab\caddy-data\pki\authorities\local\root.crt`. Copy it out for the
   student image. Do **not** copy `C:\csl-lab\attacker-caddy-data\...`: that
   CA must stay untrusted.

Save the image **after** the first start, so `caddy-data` (with the root CA
the student image trusts) is in it. Caddy's leaf certificates last 12 hours
and renew themselves whilst Caddy runs, so start Caddy on the day.

What each site does:

| Site | Used in | Behaviour |
|---|---|---|
| `http://intranet.csl.internal` | Part 3 | HTTP only; any POST shows "signed in" |
| `https://health`, `https://jobs` | Part 3 | HTTPS pages for DNS/SNI to reveal |
| `https://bank.csl.internal` | Part 3, stretch | HTTPS + HSTS (1 year); HTTP redirects |
| `https://shop.csl.internal` | stretch | HTTPS, **no** HSTS; HTTP redirects (302) |
| `192.168.75.11` port 80, any name | stretch | fake shop over HTTP; POST shows "checkout unavailable" |
| `192.168.75.11` port 443, `bank` | stretch | fake bank, cert from the untrusted attacker CA |

## 4. Student image (Windows 10)

Scripted by `windows\Setup-StudentImage.ps1` (see section 3). It also sets
the Edge policy `AutomaticHttpsDefault = 0` and the Chrome policies
`HttpsUpgradesEnabled = 0` and `HttpsOnlyMode = disallowed`, so neither
browser quietly tries `https://` for the `http://` Shop favourite;
`-KeepHttpsUpgrade` skips those. Chrome gets the same favourites as a managed
"CSL Cafe" bookmarks folder (`ManagedBookmarks`, bookmarks bar shown), so
students can use either browser.

- **Wireshark** (with Npcap). The live capture reads from stdin (`-i -`).
- **Lab root CA** in the machine's Trusted Root store (admin prompt):
  `certutil -addstore -f Root root.crt`. Edge and Chrome use this store;
  Firefox may not unless `security.enterprise_roots.enabled` is on, so the
  sheet says Edge or Chrome.
- **Edge favourites bar** with exactly these URLs (note the schemes):
  `http://intranet.csl.internal`, `http://shop.csl.internal`,
  `https://bank.csl.internal`, `https://health.csl.internal`,
  `https://jobs.csl.internal`. The Shop favourite is `http://` on purpose: an
  old bookmark is the realistic way a downgrade starts. It also means you
  don't depend on Edge treating `.internal` typed in the address bar as a URL
  rather than a search.
- **Proxy bypass.** If the image sets the university proxy, a victim with the
  cable unplugged can't reach the proxy and nothing loads. Add
  `*.csl.internal;192.168.75.*;172.16.42.*;172.22.252.*` to the proxy
  exceptions (or the PAC file / GPO, which may need IT).
- **OpenSSH client** (`ssh`, `scp`): present by default on Windows 10 1809
  and later; check.
- Students must be able to **unplug the network cable** without being logged
  out or losing anything. Check what happens to the session, mapped drives
  and roaming profile with the cable out for an hour.

## 5. Pineapples (Mark VII)

Do this with internet access (the module store and `opkg` need it):

- Update firmware, and set the management password you will give students.
- Install modules: **Evil Portal**, and `tcpdump` (`opkg update && opkg install
  tcpdump` over SSH, or the tcpdump module). Check both are on firmware 2.x.
- In Evil Portal, create a portal called **CSL Cafe** from the basic
  template: "CSL Cafe free Wi-Fi, sign in with your email address and
  password". Make sure its log records the submitted fields.
- Settings, Networking: connect the **wireless client (wlan2) to `CSL-Cafe`**
  and check it gets a `192.168.75.x` address and that
  `nslookup intranet.csl.internal` works over SSH. Pre-doing this removes a
  step that eats student time.
- Note the client subnet the Pineapple hands to victims (default
  `172.16.42.0/24`, but the management address looks customised to
  `172.22.252.10x`, so check). Add it to the proxy bypass above.
- Clear the SSID pool and filters, and set PineAP to Passive, so every team
  starts clean.

## 6. The tasks: how they work and what to expect

**Getting the victim onto the evil twin (Part 2).** The victim turns Wi-Fi
off and on; Windows auto-joins the strongest `CSL-Cafe`, which should be the
team's own Pineapple on the desk next to the dongle. The Pineapple's client
filter (allow, victim MAC only) stops it accepting other teams' victims or
passers-by. Expected victim `ipconfig`: `172.16.42.x` (or the Pineapple's
subnet), gateway the Pineapple. The cafe sites still work, through the
Pineapple. **This is the biggest unknown: test with all four Pineapples
running and see whether each victim lands on its own team's Pineapple.** If
not, either run Parts 2 to 5 in turns (one or two teams at a time) or reduce
the competition (other teams' PineAP in Passive whilst one team attacks).

**Deauth demo.** Tutor only, against one victim, using "Deauthenticate
Client". Shows the Recon PMF column. Optional: repeat against a PMF-required
WPA2 network to show it failing.

**Part 3, capture (metadata and plain HTTP).** The live capture is

```bat
ssh root@PINEAPPLE "tcpdump -i any -U -w - not port 22 and not port 1471" | "C:\Program Files\Wireshark\Wireshark.exe" -k -i -
```

run from **cmd.exe**, not PowerShell 5 (which re-encodes binary pipes).
Expected: filter `dns` shows `health.csl.internal`, `jobs.csl.internal`,
`bank.csl.internal` queries (plus Windows noise); filter
`tls.handshake.extensions_server_name` shows the same names; Follow TLS
Stream shows ciphertext. Fallback if the pipe fails: capture to
`/tmp/capture.pcap` on the Pineapple and `scp` it back.

**Part 3, continued: plain HTTP.** Filter `http.request.method == "POST"` shows
`POST /login` to `intranet.csl.internal` with `username=...&password=...` in
the body. Edge shows "Not secure" in the address bar.

**Part 4, Evil Portal.** Unauthorised clients' HTTP is redirected to the
portal. With the NCSI records from section 3, Windows shows a "sign in to
network" notification after reconnecting; without them, the victim browses
to the Intranet favourite and gets the portal. Credentials appear in Evil
Portal's log. Students then stop the portal (or authorise the client).

**Stretch, HTTPS downgrade.** Students add dnsmasq overrides on the
Pineapple (`uci add_list dhcp.@dnsmasq[0].address='/shop.csl.internal/192.168.75.11'`,
the same for `bank`, `uci commit dhcp`, restart dnsmasq), and the victim
flushes DNS and restarts Edge. Expected:

- Shop favourite (`http://shop...`): the request goes to `.11:80`, the fake
  shop loads over HTTP, "Not secure". The POST is visible in Wireshark. The
  real shop's redirect to HTTPS never happens because the victim never
  reaches the real shop. This is SSL stripping without needing sslstrip.
- Bank favourite: HSTS (cached from Getting started) forces
  `https://bank...`, which reaches `.11:443` and gets the untrusted attacker
  certificate. Edge shows a certificate error **with no "Continue" link**
  because of HSTS.

Things to check: that Edge's automatic HTTPS upgrade doesn't change the Shop
result (if it tries `https://shop...` on `.11` it should fail the handshake,
as `.11` has no shop certificate, and fall back to HTTP; if it doesn't fall
back, the student sees an error and the point becomes "Edge's HTTPS-first
mode blocked it", which is also a good answer); that HSTS is still cached
(InPrivate windows lose it); and that the Pineapple's dnsmasq honours
`address=` via uci. Students must remove the overrides afterwards (the sheet
includes the `del_list` commands).

## 7. Running the session (two hours)

The sheet assumes all four teams run the practical work at the same time.
Within each team, one pair attacks for Parts 1 to 3, then the pairs swap seats
for Part 4. Nobody repeats a part. Submission Questions 1 (then vs now) and
7 (ethics) are done after the session.

| Time | All teams |
|---|---|
| 0:00 to 0:10 | Intro; tutor's deauth demo against one victim (Recon PMF column) |
| 0:10 to 0:25 | Getting started and Part 1 (passive, no interference) |
| 0:25 to 0:45 | Part 2, evil twin (Wi-Fi off/on "arrival") |
| 0:45 to 1:10 | Part 3, one capture: DNS/SNI, then the intranet POST |
| 1:10 to 1:35 | Swap seats; Part 4, Evil Portal |
| 1:35 to 1:50 | Stretch for teams with time, **or a tutor demo of it on the projector**; clean up |
| 1:50 to 2:00 | Debrief with captured (made-up) credentials on the projector |

Four teams can't take turns in two hours: one team's Parts 2 to 4 take about
an hour. If the section 8 test shows teams stealing each other's victims, run
**two waves of two teams** (teams on opposite sides of the room), each wave
doing Parts 2 to 4 in about 40 minutes (0:25 to 1:05, then 1:05 to 1:45),
with no stretch task. The waiting wave does Part 1 and Submission
Question 1, or the Hacktivity MITM lab.

Prep that saves student time on the day:

- Write each dongle's MAC on a label on the dongle (Windows 10 uses the
  real MAC unless random hardware addresses are on, so check), so Part 1's
  filter step is copying a label rather than hunting through Recon.
- Pineapples: wlan2 already on `CSL-Cafe`, Evil Portal's CSL Cafe portal
  already created, tcpdump installed, PineAP clean (section 5).
- Victim PCs: favourites bar and proxy exceptions in the image (section 4),
  so Getting started is just unplug, plug in the dongle, connect.
- Have one stretch-task setup ready on the tutor's own Pineapple and victim,
  so it can be shown in 5 minutes if no team gets there.

## 7a. Contingency: when the room is too crowded

Four Pineapples, the router and the university's own 2.4 GHz Wi-Fi share three
usable channels, so some teams may not get their victim onto the evil twin.
Reduce the chance first, then fall down a ladder at a fixed time so no team
loses the whole session.

**Before the session (cuts contention):**

- **Room layout** (long room, four columns of eight PCs, staff desks at the
  front). Router in the middle of the room, teams in the four corners, each
  victim PC on the outermost corner seat with its Pineapple on that desk and
  the attacker PC next to it, one row towards the middle:

  ```
   [staff]                    [staff]        front (projector)
   A-victim  .     .     B-victim    row 1   Pineapple on each victim desk
   A-attack  .     .     B-attack    row 2
     .       .     .       .         row 3
     .     [router + server]  .      rows 4-5 (column 2 or 3)
     .       .     .       .         row 6
   C-attack  .     .     D-attack    row 7
   C-victim  .     .     D-victim    row 8   back
  ```

  This puts every victim about the same distance from the router (fair to
  all teams) and as far as possible from the other teams. Plug the router
  into a middle PC running the staff image, or into the front staff PC with
  a 10 m patch cable; only the router's position matters, not the server's.
  Pineapple Open AP channels: A and D (diagonal) on 1, B and C on 11, router
  on 6, so teams sharing a channel are the furthest apart. Other team members
  sit at the PCs next to their pair; the middle of the room stays empty.
- **Two routers, if needed** (different names and channels): one in the
  middle of the front half, one in the middle of the back half. Cross them
  over: teams A and B (front) use the **back** router's network, and C and D
  (back) use the **front** one's. A team's own router is its competitor, so
  it should be the far one; the near router has a different name, so it
  doesn't compete for the victim (it only shares airtime, on another channel).
- **Router placement.** Windows joins the loudest `CSL-Cafe`, so every
  victim dongle must hear its own Pineapple well above the router. Put the
  router (on the staff desk) as far from the victim PCs as the room allows,
  low down or behind the staff PC rather than on top of it, and seat teams
  so their *victim* PC is the one further from the router. Set the Archer's
  2.4 GHz transmit power to Low (Wireless, Advanced). Everyone in the room
  can still join it, and the Pineapples win more easily. Avoid putting the
  router close to one team: that team will struggle while the others don't.
  Check it from each victim PC with `netsh wlan show networks mode=bssid`,
  which lists each `CSL-Cafe` BSSID with its signal %; the team's Pineapple
  should be clearly higher than the router.
- Keep each Pineapple next to its victim's dongle, and teams as far apart as
  the room allows. Victim dongle and Pineapple at one end of the desk, the
  next team's at the far end of theirs.
- Turn the Pineapples' transmit power down so each one only wins at close
  range. Over SSH (check the interface name with `iw dev`; not yet tested):
  `iw dev wlan0 set txpower fixed 500` (5 dBm). It resets on reboot.
- Spread the Pineapples' Open AP channels: the router on 6, two teams on 1
  and two on 11 (Settings, Networking, Open AP). Clients still join by SSID,
  and fewer radios contend on each channel. Test whether the victim still
  prefers the Pineapple when it is on a different channel from the router.
- Ask everyone in the room to turn Wi-Fi off on phones and laptops they
  aren't using for the lab (fewer probes and less airtime used).

**The ladder (decide at 0:45, when Part 3 should start):** walk round at
0:40 and check every team's victim `ipconfig`. Any team not on its Pineapple
by 0:45 drops one level; don't let a team spend Part 3's time on Part 2.

| Level | What the team does | What they lose |
|---|---|---|
| A | Evil twin of `CSL-Cafe`, automatic join (the sheet as written) | nothing |
| B | Pineapple Open AP renamed `CSL-Cafe-TeamN`; victim joins it by hand (sheet: "If your victim will not join the evil twin") | the auto-join moment only; Parts 3 and 4 are unchanged |
| C | No victim connected: analyse the recorded capture `C:\csl-lab\csl-cafe-capture.pcapng` for Part 3; Part 4 as a tutor demo on the projector | hands-on capture and portal |
| D | Room-wide failure: tutor runs Parts 2 to 4 on the projector with the staff Pineapple; everyone works from the recorded capture and the demo screenshots | everything hands-on, but every question is still answerable |

Level B should rescue most teams: a victim choosing a uniquely named network
doesn't compete with the other Pineapples' copies of `CSL-Cafe`.

**Make the recorded capture during the in-person test** (section 8, step 11),
and put it in the student image at `C:\csl-lab\csl-cafe-capture.pcapng`:

1. Victim connected to a Pineapple, live capture running as in Part 3.
2. Victim browses Health (two or three pages), Jobs (two or three pages),
   Bank, then logs in to the Intranet with made-up credentials (e.g.
   `j.smith` / `Latte2026!`). Optionally also the stretch Shop login.
3. In Wireshark, File, Save As, pcapng. Check that `dns`,
   `tls.handshake.extensions_server_name` and `http.request.method == "POST"`
   each show what the sheet says before saving the image.

The capture contains no real credentials or real traffic as long as the
victim PC is only on the cafe network, but check for Windows background
traffic you don't want to hand out (it will only be lookups that failed).

## 8. In-person test checklist

Run in this order; each step depends on the previous one.

1. Router: only `CSL-Cafe` on 2.4 GHz, fixed channel, nothing on 5 GHz.
2. Staff PC: both Caddy instances start; `caddy validate` passes on both.
3. Staff PC: `nslookup intranet.csl.internal 192.168.75.10` answers.
4. Victim PC (cable out, joined `CSL-Cafe`): all five favourites load with
   no certificate warnings; Bank shows a padlock. Proxy bypass works.
5. Victim PC: the session survives the cable being out.
6. Pineapple: wlan2 connected to `CSL-Cafe`; `nslookup` works over SSH.
7. Pineapple: Recon sees `CSL-Cafe` and the victim; the PMF column reads "no".
8. Filters + SSID pool + Advanced mode: victim's Wi-Fi off/on joins the
   Pineapple; `ipconfig` shows the Pineapple's subnet; sites still load.
9. **Four Pineapples at once, four victims: does each victim join its own
   team's Pineapple?** This decides concurrent vs turns.
10. Live capture from cmd.exe opens Wireshark; DNS and SNI names visible.
11. Intranet login visible as a POST. **Save this capture as the recorded
    capture** (section 7a).
12. Evil Portal: portal appears (with and without the NCSI records);
    credentials in the log; stopping it restores normal browsing.
13. Stretch: fake shop loads over HTTP and the POST is captured; bank gives
    a non-bypassable certificate error; `del_list` restores normal DNS.
14. Contingency: rename one Pineapple's Open AP to `CSL-Cafe-Team1`, join it by
    hand from a victim, and check Parts 3 and 4 still work; try the txpower
    and channel settings from section 7a and note whether victims still pick
    their own Pineapple.
15. Clean-up steps return the Pineapple to a clean state for the next team.
16. Menu names in the sheet (PineAP Advanced, "Beacon Response",
    "Broadcast SSID Pool", "Allow Associations", Settings, Networking, Evil
    Portal) match firmware 2.x; fix the sheet where they don't, and add
    screenshots from this test to the sheet.

## 9. Known unknowns

- Caddyfiles not validated (no Caddy available where they were written); `Setup-StaffImage.ps1` runs `caddy validate` on both and stops if either fails.
- Mark VII 2.x menu names, the Evil Portal module's availability on 2.x,
  `tcpdump` packaging, and dnsmasq configuration via `uci` are from
  documentation and memory, not tested.
- Whether Windows 10 shows the captive-portal notification depends on the
  NCSI records and Windows' current behaviour.
- Edge's automatic HTTPS upgrade may change the stretch task's Shop result
  (see section 6); `Setup-StudentImage.ps1` turns it off by policy.
- The PowerShell scripts in `windows\` were written without a Windows PC to
  run them on. Expect small fixes on the first run. Least certain:
  Technitium's silent-install switches and API parameter names
  (`user/changePassword`, `zones/records/add`, `settings/set recursion`),
  whether the managed Edge favourites and Chrome bookmarks policies apply
  on these PCs, and
  Caddy creating the CA from the temporary localhost config.
