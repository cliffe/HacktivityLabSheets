<#
.SYNOPSIS
  Last step before capturing the staff or student image for the CSL Wireless Security lab.

.DESCRIPTION
  Run elevated on either image, after testing and immediately before you capture it. It:
    1. removes local accounts created since the setup script first ran (with their
       profiles), and members added to Administrators since then, asking for each one
       unless -Force is given;
    2. lists every remaining enabled local account, so you can spot one that was made
       before the setup script ran;
    3. deletes saved Wi-Fi profiles for the lab networks (CSL-Cafe*) and any you name;
    4. staff PC: stops Caddy and Technitium, takes the lab addresses off the adapter, removes the
       temporary cert-server firewall rule and checks the lab root CA is still there;
    5. student PC: checks the lab root CA is trusted and no attacker CA is;
    6. deletes the downloads and the account baseline in C:\ProgramData\CSL-Lab.
  The software, the lab CA, firewall rules and Edge/Chrome policies the setup scripts added are
  part of the image and are kept.

.EXAMPLE
  .\Cleanup-BeforeImage.ps1
  .\Cleanup-BeforeImage.ps1 -WhatIf                  # show what would be removed
  .\Cleanup-BeforeImage.ps1 -ExtraWifiProfiles 'CSL-Cafe-Front','Pineapple_1234'
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [switch]$Force,
    [string[]]$ExtraWifiProfiles = @(),
    [string[]]$ExtraAccounts = @(),   # names to remove even if they predate the baseline
    [string]$LabDir = 'C:\csl-lab'
)

$ErrorActionPreference = 'Stop'
# $PSScriptRoot is empty in some hosts (ISE, F8 selections, some PS 5.1 launchers).
$ScriptDir = if ($PSScriptRoot) { $PSScriptRoot }
             elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path }
             else { (Get-Location).Path }
if (-not (Test-Path (Join-Path $ScriptDir 'CslLab.Common.psm1'))) {
    throw "CslLab.Common.psm1 not found in '$ScriptDir'. cd into the kit's windows folder and run: powershell -ExecutionPolicy Bypass -File .\<script>.ps1"
}
Import-Module (Join-Path $ScriptDir 'CslLab.Common.psm1') -Force
Assert-CslAdmin

function Confirm-Step([string]$What) {
    if ($Force) { return $PSCmdlet.ShouldProcess($What) }
    if (-not $PSCmdlet.ShouldProcess($What)) { return $false }
    (Read-Host "    $What ? [y/N]") -match '^(y|yes)$'
}

$problems = 0
$me = [Security.Principal.WindowsIdentity]::GetCurrent().Name

# ---------------------------------------------------------------- 1. accounts
Write-CslStep 'Accounts added since setup'
$base = Get-CslAccountBaseline
if (-not $base) {
    Write-CslWarn 'no baseline found (setup scripts not run here, or cleanup already ran): only -ExtraAccounts are removed'
    $baseUsers = @(Get-CslLocalUser | ForEach-Object { $_.Name })
    $baseAdmins = $null
} else {
    Write-CslOk "baseline taken $($base.Taken)"
    $baseUsers = @($base.Users)
    $baseAdmins = @($base.Administrators)
}
$newUsers = @(Get-CslLocalUser | Where-Object { $baseUsers -notcontains $_.Name -or $ExtraAccounts -contains $_.Name })
if (-not $newUsers) { Write-CslOk 'no new local accounts' }
foreach ($u in $newUsers) {
    if ("$env:COMPUTERNAME\$($u.Name)" -eq $me) {
        Write-CslFail "$($u.Name) is the account running this script: sign in as another administrator and run it again"
        $problems++; continue
    }
    if (Confirm-Step "Remove local account '$($u.Name)' and its profile") {
        $prof = Get-CimInstance Win32_UserProfile | Where-Object { $_.SID -eq $u.SID }
        if ($prof -and $prof.Loaded) { Write-CslWarn "profile of $($u.Name) is loaded (signed in?); sign it out first"; $problems++; continue }
        if ($prof) { $prof | Remove-CimInstance }
        Remove-CslLocalUser -Name $u.Name -SID $u.SID
        Write-CslOk "removed $($u.Name)"
    } else { Write-CslWarn "kept $($u.Name)"; $problems++ }
}

if ($null -ne $baseAdmins) {
    $nowAdmins = @((Get-CslAccountSnapshot).Administrators)
    $added = @($nowAdmins | Where-Object { $baseAdmins -notcontains $_ })
    if (-not $added) { Write-CslOk 'Administrators group unchanged' }
    foreach ($a in $added) {
        if ($a -eq $me) { Write-CslWarn "$a (you) was added to Administrators after setup; remove it yourself afterwards if it should not stay"; $problems++; continue }
        if (Confirm-Step "Remove '$a' from Administrators") {
            try { Remove-LocalGroupMember -SID 'S-1-5-32-544' -Member $a -ErrorAction Stop }
            catch {
                $grp = (New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')).Translate([Security.Principal.NTAccount]).Value.Split('\')[-1]
                Invoke-CslNative net.exe @('localgroup', $grp, $a, '/delete') | Out-Null
            }
            Write-CslOk "removed $a from Administrators"
        } else { Write-CslWarn "kept $a in Administrators"; $problems++ }
    }
}

Write-Host '    Enabled local accounts now (check none was made for this lab before setup ran):'
Get-CslLocalUser | Where-Object Enabled | ForEach-Object {
    Write-Host ("      {0,-24} last logon {1}" -f $_.Name, $(if ($_.LastLogon) { $_.LastLogon.ToString('yyyy-MM-dd HH:mm') } else { 'never' }))
}

# ---------------------------------------------------------------- 2. Wi-Fi profiles
Write-CslStep 'Saved Wi-Fi profiles'
$profiles = @(netsh wlan show profiles 2>$null | ForEach-Object { if ($_ -match 'Profile\s*:\s+(.+?)\s*$') { $Matches[1] } })
$targets = @($profiles | Where-Object { $_ -like 'CSL-Cafe*' -or $ExtraWifiProfiles -contains $_ })
if (-not $profiles) { Write-CslOk 'none (or no Wi-Fi adapter plugged in)' }
elseif (-not $targets) { Write-CslOk "no lab profiles among: $($profiles -join ', ')" }
foreach ($t in $targets) {
    if ($PSCmdlet.ShouldProcess("Wi-Fi profile '$t'", 'Delete')) {
        netsh wlan delete profile name="$t" | Out-Null
        Write-CslOk "deleted '$t'"
    }
}
# Only CSL-Cafe* is deleted by default. Other saved networks (eduroam etc.) may belong to the image.

# ---------------------------------------------------------------- 3. staff PC
$isStaff = Test-Path (Join-Path $LabDir 'caddy.exe')
if ($isStaff) {
    Write-CslStep 'Staff PC'
    Get-Process caddy -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$LabDir\*" } | Stop-Process -Force
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*csl-cred-logger.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Write-CslOk 'Caddy and the credential logger stopped'
    # What students typed into the fake sites in Part 5 must not end up in the image.
    Remove-Item (Join-Path $LabDir 'sites\fake-shop\inputs.txt') -Force -ErrorAction SilentlyContinue
    $labIps = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -in '192.168.75.10', '192.168.75.11' }
    foreach ($ip in $labIps) {
        if ($PSCmdlet.ShouldProcess("$($ip.IPAddress) on $($ip.InterfaceAlias)", 'Remove')) {
            Remove-NetIPAddress -InputObject $ip -Confirm:$false
            Set-NetIPInterface -InterfaceIndex $ip.InterfaceIndex -AddressFamily IPv4 -Dhcp Enabled
            Write-CslOk "removed $($ip.IPAddress) from $($ip.InterfaceAlias); adapter back on DHCP"
        }
    }
    Get-NetFirewallRule -Group 'CSL Lab temporary' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    if (-not (Test-Path (Join-Path $LabDir 'caddy-data\pki\authorities\local\root.key'))) {
        Write-CslFail 'lab root CA key is missing from caddy-data: student images would stop trusting the sites'; $problems++
    } else { Write-CslOk 'lab root CA present in caddy-data (it must be in the image)' }
    Stop-CslTechnitium
    # Technitium's own logs, and the console-mode log from kit version df65ad4.
    Remove-Item (Join-Path (Get-CslTechnitiumDataDir) 'logs\*.log') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $LabDir 'logs\technitium-console.log') -Force -ErrorAction SilentlyContinue
    Write-CslOk 'deleted Technitium logs'
    if ((Get-Service DnsService -ErrorAction SilentlyContinue).StartType -ne 'Automatic') {
        Write-CslWarn 'the DnsService Windows service is not set to start automatically, so DNS will not run after boot; run Setup-StaffImage.ps1 again'
    }
    Write-Host '    Technitium admin password: keep it with the kit, not in a file on the image.'
}

# ---------------------------------------------------------------- 4. certificates
Write-CslStep 'Trusted root certificates'
$root = @(Get-ChildItem Cert:\LocalMachine\Root)
$attacker = @($root | Where-Object Subject -match 'Attacker CA')
foreach ($c in $attacker) {
    if ($PSCmdlet.ShouldProcess($c.Subject, 'Remove from Trusted Root')) { Remove-Item $c.PSPath; Write-CslOk "removed untrusted-by-design '$($c.Subject)'" }
}
$lab = @($root | Where-Object Subject -match 'CSL Lab Root CA')
if ($isStaff) {
    if ($lab) { Write-CslWarn 'the staff PC trusts the lab CA; harmless, but the setup does not need it' }
} elseif (-not $lab) {
    Write-CslFail 'student PC does not trust the CSL Lab Root CA: run Setup-StudentImage.ps1'; $problems++
} elseif ($lab.Count -gt 1) {
    Write-CslWarn "$($lab.Count) CSL Lab Root CAs are trusted; only the current one is needed"
} else { Write-CslOk "CSL Lab Root CA trusted ($($lab[0].Thumbprint))" }

# ---------------------------------------------------------------- 5. scratch files
Write-CslStep 'Scratch files'
$state = Join-Path $env:ProgramData 'CSL-Lab'
if ($problems) {
    Write-CslWarn "kept $state (and the account baseline) because $problems item(s) above need attention; re-run when fixed"
} elseif (Test-Path $state) {
    if ($PSCmdlet.ShouldProcess($state, 'Delete')) { Remove-Item $state -Recurse -Force; Write-CslOk "deleted $state (downloads, account baseline)" }
} else { Write-CslOk 'nothing to delete' }

Write-CslStep 'Done'
if ($problems) { Write-CslFail "$problems item(s) need attention before you capture the image" }
else { Write-CslOk 'ready to capture the image' }
