<#
.SYNOPSIS
  Builds the student PC image for the CSL Wireless Security lab (README section 4).

.DESCRIPTION
  Run once, elevated, on the PC that will become the student image. It:
    1. records the local accounts (for Cleanup-BeforeImage.ps1);
    2. fetches the lab root CA from the staff PC (Setup-StaffImage.ps1 -ServeCert), checks
       its SHA-256 against the value the staff script printed, and trusts it machine-wide;
    3. installs Wireshark (and, with -WithNpcap, starts the Npcap installer, which
       cannot run silently);
    4. checks the OpenSSH client and adds it if it is missing;
    5. sets the Edge favourites bar and Chrome bookmarks bar (CSL Cafe folder) and turns off
       both browsers' automatic HTTPS upgrade, by policy;
    6. reports proxy settings that would stop a PC with its cable unplugged from loading
       the cafe sites.
  Safe to re-run.

.EXAMPLE
  .\Setup-StudentImage.ps1 -StaffHost 10.1.2.3 -CertSha256 <hash printed by the staff script>
.EXAMPLE
  .\Setup-StudentImage.ps1 -CertFile E:\csl-lab-root.crt -CertSha256 <hash> -WiresharkInstaller E:\Wireshark-4.4.2-x64.exe
#>
[CmdletBinding(DefaultParameterSetName = 'Fetch')]
param(
    [Parameter(ParameterSetName = 'Fetch', Mandatory)][string]$StaffHost,
    [Parameter(ParameterSetName = 'Fetch')][int]$Port = 8080,
    [Parameter(ParameterSetName = 'File', Mandatory)][string]$CertFile,
    [Parameter(Mandatory)][ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$CertSha256,
    [string]$WiresharkInstaller = 'https://www.wireshark.org/download/win64/Wireshark-latest-x64.exe',
    [switch]$WithNpcap,
    [string]$NpcapInstaller = 'https://npcap.com/dist/npcap-1.79.exe',
    [switch]$SkipWireshark,
    [switch]$KeepHttpsUpgrade
)

$ErrorActionPreference = 'Stop'
# $PSScriptRoot is empty in some hosts (ISE, F8 selections, some PS 5.1 launchers).
$ScriptDir = if ($PSScriptRoot) { $PSScriptRoot }
             elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path }
             else { (Get-Location).Path }
if (-not (Test-Path (Join-Path $ScriptDir 'CslLab.Common.psm1'))) {
    throw "CslLab.Common.psm1 not found in '$ScriptDir'. cd into the kit's windows folder and run: powershell -ExecutionPolicy Bypass -File .\<script>.ps1"
}
Import-Module (Join-Path $ScriptDir 'CslLab.Common.psm1') -Force
Assert-CslAdmin

# ---------------------------------------------------------------- 1. accounts
Write-CslStep 'Recording local accounts'
Save-CslAccountBaseline

# ---------------------------------------------------------------- 2. lab CA
Write-CslStep 'Lab root CA'
if ($PSCmdlet.ParameterSetName -eq 'Fetch') {
    $crtPath = Get-CslDownload -Source "http://${StaffHost}:$Port/csl-lab-root.crt" -FileName 'csl-lab-root.crt'
} else {
    $crtPath = Get-CslDownload -Source $CertFile -FileName 'csl-lab-root.crt'
}
$cert = New-Object Security.Cryptography.X509Certificates.X509Certificate2($crtPath)
$hash = Get-CslCertSha256 $cert
# The download is plain HTTP, so the hash check is what makes it safe to trust.
if ($hash -ne $CertSha256.ToUpperInvariant()) {
    throw "Certificate SHA-256 is $hash, expected $CertSha256. Not trusting it."
}
$bc = $cert.Extensions | Where-Object { $_ -is [Security.Cryptography.X509Certificates.X509BasicConstraintsExtension] }
if (-not $bc -or -not $bc.CertificateAuthority) { throw 'That certificate is not a CA certificate.' }
if ($cert.Subject -notmatch 'CSL Lab Root CA') { throw "Unexpected subject '$($cert.Subject)'." }
Write-CslOk "SHA-256 matches; $($cert.Subject), expires $($cert.NotAfter.ToString('yyyy-MM-dd'))"

# Remove an older lab CA (e.g. the staff image was rebuilt) and anything from the
# attacker server's CA, which must never be trusted.
Get-ChildItem Cert:\LocalMachine\Root |
    Where-Object { ($_.Subject -match 'CSL Lab Root CA' -and $_.Thumbprint -ne $cert.Thumbprint) -or $_.Subject -match 'Attacker CA' } |
    ForEach-Object { Write-CslWarn "removing $($_.Subject) ($($_.Thumbprint))"; Remove-Item $_.PSPath }
if (Test-Path "Cert:\LocalMachine\Root\$($cert.Thumbprint)") { Write-CslOk 'already trusted' }
else { Import-Certificate -FilePath $crtPath -CertStoreLocation Cert:\LocalMachine\Root | Out-Null; Write-CslOk 'added to Trusted Root (machine)' }

# ---------------------------------------------------------------- 3. Wireshark
Write-CslStep 'Wireshark'
# The installer may register under the 64-bit or the 32-bit (WOW6432Node) uninstall key, so check
# both, and the program folders.
$ws = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                       'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue |
    Where-Object { $_.PSObject.Properties['DisplayName'] -and $_.DisplayName -like 'Wireshark*' } | Select-Object -First 1
$wsExe = @("$env:ProgramFiles\Wireshark\Wireshark.exe", "${env:ProgramFiles(x86)}\Wireshark\Wireshark.exe") |
    Where-Object { Test-Path $_ } | Select-Object -First 1
if ($SkipWireshark) { Write-CslWarn 'skipped (-SkipWireshark)' }
elseif ($ws -or $wsExe) { Write-CslOk "$(if ($ws) { $ws.DisplayName } else { $wsExe }) already installed" }
else {
    $exe = Get-CslDownload -Source $WiresharkInstaller -FileName 'wireshark-setup.exe'
    Test-CslSignature -Path $exe -SignerPattern 'Wireshark Foundation'
    $p = Start-Process -FilePath $exe -ArgumentList '/S', '/desktopicon=yes' -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Wireshark setup exited with $($p.ExitCode)" }
    Write-CslOk 'installed (the lab captures from ssh on stdin, so it works without Npcap)'
}
if ($WithNpcap) {
    if (Get-Service npcap -ErrorAction SilentlyContinue) { Write-CslOk 'Npcap already installed' }
    else {
        $exe = Get-CslDownload -Source $NpcapInstaller -FileName 'npcap-setup.exe'
        Test-CslSignature -Path $exe -SignerPattern 'Insecure\.Com'
        Write-Host '    The free Npcap cannot install silently: click through its installer now.'
        Start-Process -FilePath $exe -Wait
    }
}

# ---------------------------------------------------------------- 4. OpenSSH
Write-CslStep 'OpenSSH client'
if (Get-Command ssh.exe -ErrorAction SilentlyContinue) { Write-CslOk "present: $((Get-Command ssh.exe).Source)" }
else {
    try {
        Get-WindowsCapability -Online -Name 'OpenSSH.Client*' | Where-Object State -ne 'Installed' | Add-WindowsCapability -Online | Out-Null
        Write-CslOk 'installed'
    } catch {
        Write-CslWarn "could not add OpenSSH.Client ($($_.Exception.Message)); WSUS may block Features on Demand, ask IT"
    }
}

# ---------------------------------------------------------------- 5. Edge
Write-CslStep 'Edge policies'
$edge = 'HKLM:\SOFTWARE\Policies\Microsoft\Edge'
New-Item -Path $edge -Force | Out-Null
$existing = (Get-ItemProperty $edge -Name ManagedFavorites -ErrorAction SilentlyContinue)
if ($existing -and $existing.ManagedFavorites -notmatch 'CSL Cafe') {
    Write-CslWarn 'ManagedFavorites was already set (by a GPO?); replacing it here, but a GPO refresh will put the old one back'
}
# Exact schemes matter: Shop is http:// on purpose (the stretch task's downgrade starts there).
$favs = @(
    @{ toplevel_name = 'CSL Cafe' },
    @{ name = 'Intranet'; url = 'http://intranet.csl.internal/' },
    @{ name = 'Shop';     url = 'http://shop.csl.internal/' },
    @{ name = 'Bank';     url = 'https://bank.csl.internal/' },
    @{ name = 'Health';   url = 'https://health.csl.internal/' },
    @{ name = 'Jobs';     url = 'https://jobs.csl.internal/' }
)
Set-ItemProperty -Path $edge -Name ManagedFavorites -Value (ConvertTo-Json $favs -Compress) -Type String
Set-ItemProperty -Path $edge -Name FavoritesBarEnabled -Value 1 -Type DWord
Write-CslOk 'favourites bar: CSL Cafe > Intranet, Shop, Bank, Health, Jobs'
if ($KeepHttpsUpgrade) { Write-CslWarn 'left Edge automatic HTTPS upgrade alone (-KeepHttpsUpgrade)' }
else {
    # Edge otherwise tries https:// first for http:// links, which hides the stretch task's downgrade.
    Set-ItemProperty -Path $edge -Name AutomaticHttpsDefault -Value 0 -Type DWord
    Write-CslOk 'automatic HTTPS upgrade off (AutomaticHttpsDefault = 0)'
}
$edgeExe = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($edgeExe) { Write-Host '    Check in Edge at edge://policy after the next sign-in.' }
else {
    # Windows 10 1903 shipped with the old (EdgeHTML) Edge, which ignores these policies: no favourites bar.
    Write-CslWarn 'only the old (legacy) Edge is installed: it ignores these policies, so it will have no CSL Cafe favourites. Install the current Edge, or have students use Chrome.'
}

# ---------------------------------------------------------------- 5b. Chrome
Write-CslStep 'Chrome policies'
$chrome = 'HKLM:\SOFTWARE\Policies\Google\Chrome'
New-Item -Path $chrome -Force | Out-Null
$existing = (Get-ItemProperty $chrome -Name ManagedBookmarks -ErrorAction SilentlyContinue)
if ($existing -and $existing.ManagedBookmarks -notmatch 'CSL Cafe') {
    Write-CslWarn 'ManagedBookmarks was already set (by a GPO?); replacing it here, but a GPO refresh will put the old one back'
}
# Same list format as Edge's ManagedFavorites; Chrome shows it as a folder on the bookmarks bar.
Set-ItemProperty -Path $chrome -Name ManagedBookmarks -Value (ConvertTo-Json $favs -Compress) -Type String
Set-ItemProperty -Path $chrome -Name BookmarkBarEnabled -Value 1 -Type DWord
Write-CslOk 'bookmarks bar: CSL Cafe > Intranet, Shop, Bank, Health, Jobs'
if ($KeepHttpsUpgrade) { Write-CslWarn 'left Chrome automatic HTTPS upgrade alone (-KeepHttpsUpgrade)' }
else {
    # HttpsUpgradesEnabled = 0: no silent http:// -> https:// upgrade (hides the stretch task's
    # downgrade). HttpsOnlyMode = disallowed: "Always use secure connections" can't be switched
    # on, so there is no warning page in front of the http:// sites.
    Set-ItemProperty -Path $chrome -Name HttpsUpgradesEnabled -Value 0 -Type DWord
    Set-ItemProperty -Path $chrome -Name HttpsOnlyMode -Value 'disallowed' -Type String
    Write-CslOk 'automatic HTTPS upgrade off (HttpsUpgradesEnabled = 0, HttpsOnlyMode = disallowed)'
}
$chromeExe = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($chromeExe) { Write-Host '    Check in Chrome at chrome://policy (Reload policies) after the next sign-in.' }
else { Write-CslWarn 'Chrome is not installed; these policies take effect if it is installed later' }

# ---------------------------------------------------------------- 6. proxy report
Write-CslStep 'Proxy settings (report only)'
$bypass = '*.csl.internal;192.168.75.*;172.16.42.*;172.22.252.*'
$found = $false
foreach ($k in 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings',
               'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings') {
    $s = Get-ItemProperty $k -ErrorAction SilentlyContinue
    if (-not $s) { continue }
    foreach ($n in 'ProxyEnable', 'ProxyServer', 'AutoConfigURL', 'ProxyOverride') {
        if ($s.PSObject.Properties[$n] -and $s.$n) { Write-Host "    $k : $n = $($s.$n)"; if ($n -ne 'ProxyOverride') { $found = $true } }
    }
}
$ep = Get-ItemProperty $edge -ErrorAction SilentlyContinue
foreach ($n in 'ProxySettings', 'ProxyServer', 'ProxyPacUrl', 'ProxyBypassList') {
    if ($ep.PSObject.Properties[$n]) { Write-Host "    Edge policy $n = $($ep.$n)"; $found = $true }
}
$cp = Get-ItemProperty $chrome -ErrorAction SilentlyContinue
foreach ($n in 'ProxyMode', 'ProxySettings', 'ProxyServer', 'ProxyPacUrl', 'ProxyBypassList') {
    if ($cp.PSObject.Properties[$n]) { Write-Host "    Chrome policy $n = $($cp.$n)"; $found = $true }
}
Write-Host "    $((netsh winhttp show proxy) -join ' ' -replace '\s+', ' ')"
if ($found) { Write-CslWarn "a proxy is configured: make sure students' sessions bypass $bypass (the HKCU values above are for this account only; the student policy is usually a GPO, so ask IT)" }
else { Write-CslOk 'no proxy configured for this account or by machine policy' }

Write-CslStep 'Student image set up'
Write-Host @"
    Still to check by hand (README section 4):
      - unplug the cable for an hour: no sign-out, no lost files, no roaming-profile errors;
      - on the cafe network, the Edge favourites and Chrome bookmarks open without certificate warnings.
    Before capturing the image:  .\Cleanup-BeforeImage.ps1
"@
