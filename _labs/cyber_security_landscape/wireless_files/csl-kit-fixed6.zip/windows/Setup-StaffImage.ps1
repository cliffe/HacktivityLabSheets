<#
.SYNOPSIS
  Builds the staff PC image for the CSL Wireless Security lab (README section 3).

.DESCRIPTION
  Run once, elevated, on the PC that will become the staff image. It:
    1. records the local accounts (for Cleanup-BeforeImage.ps1);
    2. installs Caddy to C:\csl-lab, with the Caddyfiles and sites from this kit;
    3. generates the lab root CA ("CSL Lab Root CA") and exports it to C:\csl-lab\csl-lab-root.crt;
    4. installs Technitium DNS Server, sets its admin password, creates the
       csl.internal zone (and the Windows connectivity-check zones) and denies recursion;
    5. adds inbound firewall rules for DNS and web, limited to 192.168.75.0/24.
  It does not give the lab adapter its addresses or start the web servers: Start-StaffLab.ps1
  does that on the day, because the USB adapter may get a different name on another PC.

  Safe to re-run: each step checks what is already there.

  With -ServeCert it does nothing else: it serves C:\csl-lab\csl-lab-root.crt over HTTP on
  port 8080 so Setup-StudentImage.ps1 can fetch it, until you press Ctrl+C.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\Setup-StaffImage.ps1
.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\Setup-StaffImage.ps1 -ServeCert
.EXAMPLE
  # No internet on the PC: pass installers copied from a USB stick.
  .\Setup-StaffImage.ps1 -CaddyZip E:\caddy_2.8.4_windows_amd64.zip -CaddyChecksums E:\caddy_2.8.4_checksums.txt -TechnitiumSetup E:\DnsServerSetup.zip
#>
[CmdletBinding()]
param(
    [string]$CaddyVersion = '2.8.4',
    [string]$CaddyZip,          # URL or path; default is the GitHub release for $CaddyVersion
    [string]$CaddyChecksums,    # URL or path to caddy_<ver>_checksums.txt
    [string]$TechnitiumSetup = 'https://download.technitium.com/dns/DnsServerSetup.zip',
    [string]$KitDir,            # the wireless_security kit folder; default: the parent of this script's folder
    [string]$LabDir = 'C:\csl-lab',
    [switch]$NoConnectivityZones,
    [switch]$ServeCert,
    [int]$ServePort = 8080
)

$ErrorActionPreference = 'Stop'
# $PSScriptRoot is empty in some hosts (ISE, F8 selections, some PS 5.1 launchers).
$ScriptDir = if ($PSScriptRoot) { $PSScriptRoot }
             elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path }
             else { (Get-Location).Path }
if (-not (Test-Path (Join-Path $ScriptDir 'CslLab.Common.psm1'))) {
    throw "CslLab.Common.psm1 not found in '$ScriptDir'. cd into the kit's windows folder and run: powershell -ExecutionPolicy Bypass -File .\<script>.ps1"
}
Import-Module (Join-Path $ScriptDir 'CslLab.Common.psm1') -Force
if (-not $KitDir) { $KitDir = Split-Path $ScriptDir -Parent }
Assert-CslAdmin

$LabIp   = '192.168.75.10'
$LabNet  = '192.168.75.0/24'
$Caddy   = Join-Path $LabDir 'caddy.exe'
$RootCrt = Join-Path $LabDir 'caddy-data\pki\authorities\local\root.crt'
$PubCrt  = Join-Path $LabDir 'csl-lab-root.crt'

# ---------------------------------------------------------------- -ServeCert
if ($ServeCert) {
    if (-not (Test-Path $PubCrt)) { throw "$PubCrt not found; run this script without -ServeCert first." }
    if (-not (Test-Path $Caddy))  { throw "$Caddy not found; run this script without -ServeCert first." }
    $cert = New-Object Security.Cryptography.X509Certificates.X509Certificate2($PubCrt)
    $hash = Get-CslCertSha256 $cert
    $pub  = Join-Path (Get-CslStateDir) 'pub'
    New-Item -ItemType Directory -Path $pub -Force | Out-Null
    Copy-Item $PubCrt (Join-Path $pub 'csl-lab-root.crt') -Force
    $ruleName = "CSL Lab TEMP cert server $ServePort"
    New-NetFirewallRule -DisplayName $ruleName -Group 'CSL Lab temporary' -Direction Inbound `
        -Action Allow -Protocol TCP -LocalPort $ServePort | Out-Null
    $ips = Get-NetIPAddress -AddressFamily IPv4 |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -notlike '192.168.75.*' } |
        ForEach-Object { $_.IPAddress }
    Write-Host ''
    Write-Host "Serving the lab root CA. On each student image PC run (elevated):" -ForegroundColor Cyan
    foreach ($ip in @($ips) + @($env:COMPUTERNAME)) {
        Write-Host "  .\Setup-StudentImage.ps1 -StaffHost $ip -CertSha256 $hash"
    }
    Write-Host "`nPress Ctrl+C to stop. The firewall rule is removed when you do."
    try {
        $ErrorActionPreference = 'Continue'   # Caddy logs to stderr; see Invoke-CslNative
        & $Caddy file-server --root $pub --listen ":$ServePort"
    } finally {
        Get-NetFirewallRule -Group 'CSL Lab temporary' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
        Remove-Item $pub -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host 'Stopped serving; temporary firewall rule removed.'
    }
    return
}

# ---------------------------------------------------------------- 1. accounts
Write-CslStep 'Recording local accounts'
Save-CslAccountBaseline

# ---------------------------------------------------------------- 2. Caddy
Write-CslStep "Installing Caddy $CaddyVersion to $LabDir"
foreach ($f in @('staff_server\Caddyfile', 'staff_server\Caddyfile.attacker', 'staff_server\sites')) {
    if (-not (Test-Path (Join-Path $KitDir $f))) { throw "Kit file $f not found under $KitDir; pass -KitDir." }
}
New-Item -ItemType Directory -Path $LabDir -Force | Out-Null

$haveVersion = $null
if (Test-Path $Caddy) { $haveVersion = ((Invoke-CslNative $Caddy @('version')).Output -join '') -replace '^v(\S+).*', '$1' }
if ($haveVersion -eq $CaddyVersion) {
    Write-CslOk "caddy $haveVersion already installed"
} else {
    $zipName = "caddy_${CaddyVersion}_windows_amd64.zip"
    $sumName = "caddy_${CaddyVersion}_checksums.txt"
    $base = "https://github.com/caddyserver/caddy/releases/download/v$CaddyVersion"
    if (-not $CaddyZip)       { $CaddyZip = "$base/$zipName" }
    if (-not $CaddyChecksums) { $CaddyChecksums = "$base/$sumName" }
    $zip = Get-CslDownload -Source $CaddyZip -FileName $zipName
    $sums = Get-CslDownload -Source $CaddyChecksums -FileName $sumName
    # The release's checksums file lists SHA-512 hashes. This catches a corrupt or swapped
    # zip, though both files come from the same release page.
    $line = Get-Content $sums | Where-Object { $_ -match "\s$([regex]::Escape($zipName))$" } | Select-Object -First 1
    if (-not $line) { throw "$zipName is not listed in $sumName" }
    $expected = ($line -split '\s+')[0].ToUpperInvariant()
    $actual = (Get-FileHash -Path $zip -Algorithm SHA512).Hash
    if ($actual -ne $expected) { throw "SHA-512 mismatch for $zipName" }
    Write-CslOk 'SHA-512 matches the release checksums'
    $tmp = Join-Path (Get-CslStateDir) 'caddy-unzip'
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    Expand-Archive -Path $zip -DestinationPath $tmp
    Get-Process caddy -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Caddy } | Stop-Process -Force
    Copy-Item (Join-Path $tmp 'caddy.exe') $Caddy -Force
    Remove-Item $tmp -Recurse -Force
    Write-CslOk "installed $((Invoke-CslNative $Caddy @('version')).Output -join '')"
}

Copy-Item (Join-Path $KitDir 'staff_server\Caddyfile') $LabDir -Force
Copy-Item (Join-Path $KitDir 'staff_server\Caddyfile.attacker') $LabDir -Force
$sites = Join-Path $LabDir 'sites'
if (Test-Path $sites) { Remove-Item $sites -Recurse -Force }
Copy-Item (Join-Path $KitDir 'staff_server\sites') $sites -Recurse
Write-CslOk 'copied Caddyfile, Caddyfile.attacker and sites\'

foreach ($cfg in 'Caddyfile', 'Caddyfile.attacker') {
    $v = Invoke-CslNative $Caddy @('validate', '--adapter', 'caddyfile', '--config', (Join-Path $LabDir $cfg))
    if ($v.ExitCode -ne 0) {
        $v.Output | ForEach-Object { Write-Host "      $_" }
        throw "caddy validate failed for $cfg (output above)"
    }
    Write-CslOk "$cfg is valid"
}

# ---------------------------------------------------------------- 3. root CA
Write-CslStep 'Lab root CA'
if (Test-Path $RootCrt) {
    Write-CslOk 'root CA already exists; keeping it (student images already trust it)'
} else {
    # Start Caddy briefly with the same storage and CA name as the real Caddyfile, bound to
    # localhost only, so the CA is created without needing the lab adapter.
    $init = Join-Path (Get-CslStateDir) 'Caddyfile.ca-init'
    @"
{
	admin off
	storage file_system $($LabDir -replace '\\', '/')/caddy-data
	skip_install_trust
	auto_https disable_redirects
	pki {
		ca local {
			name "CSL Lab Root CA"
		}
	}
}
https://csl-ca-init.localhost:8443 {
	bind 127.0.0.1
	tls internal
	respond "ok"
}
"@ | Set-Content -Path $init -Encoding ASCII
    $p = Start-Process -FilePath $Caddy -ArgumentList 'run', '--adapter', 'caddyfile', '--config', "`"$init`"" `
        -WindowStyle Hidden -PassThru
    $deadline = (Get-Date).AddSeconds(60)
    while (-not (Test-Path $RootCrt) -and (Get-Date) -lt $deadline -and -not $p.HasExited) { Start-Sleep -Seconds 1 }
    Start-Sleep -Seconds 2
    if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force }
    Remove-Item $init -Force
    if (-not (Test-Path $RootCrt)) { throw "Caddy did not create $RootCrt; run '$Caddy run --config $LabDir\Caddyfile' by hand to see why." }
    Write-CslOk 'generated'
}
Copy-Item $RootCrt $PubCrt -Force
$cert = New-Object Security.Cryptography.X509Certificates.X509Certificate2($PubCrt)
$CertSha256 = Get-CslCertSha256 $cert
Write-CslOk "subject  $($cert.Subject)"
Write-CslOk "expires  $($cert.NotAfter.ToString('yyyy-MM-dd'))"
Write-CslOk "SHA-256  $CertSha256"
Set-Content -Path (Join-Path $LabDir 'csl-lab-root.sha256.txt') -Value $CertSha256 -Encoding ASCII
# Never copy or trust attacker-caddy-data: its CA must stay untrusted.

# ---------------------------------------------------------------- 4. Technitium
Write-CslStep 'Technitium DNS Server'
if (Get-CslTechnitiumExe) {
    Write-CslOk 'already installed'
} else {
    $pkg = Get-CslDownload -Source $TechnitiumSetup -FileName ([IO.Path]::GetFileName(($TechnitiumSetup -split '\?')[0]))
    $exe = $pkg
    if ($pkg -like '*.zip') {
        $tmp = Join-Path (Get-CslStateDir) 'technitium-unzip'
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        Expand-Archive -Path $pkg -DestinationPath $tmp
        $exe = (Get-ChildItem $tmp -Filter '*.exe' -Recurse | Select-Object -First 1).FullName
    }
    $sig = Get-AuthenticodeSignature -FilePath $exe
    if ($sig.Status -eq 'Valid') { Write-CslOk "signature: $($sig.SignerCertificate.Subject)" }
    else { Write-CslWarn "installer signature is $($sig.Status); continuing because Technitium's setup may be unsigned" }
    # Inno Setup silent switches. The installer also fetches the .NET runtime it needs.
    $proc = Start-Process -FilePath $exe -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART' -Wait -PassThru
    if ($proc.ExitCode -ne 0) { throw "Technitium setup exited with $($proc.ExitCode); run $exe by hand." }
    Write-CslOk 'installed'
}

# 127.0.0.1 rather than localhost, and a direct proxy, so a system proxy can't intercept the API calls.
$api = 'http://127.0.0.1:5380/api'
[Net.WebRequest]::DefaultWebProxy = New-Object Net.WebProxy

Write-Host '    checking the .NET runtime'
if (-not (Get-CslTechnitiumExe)) { throw 'Technitium DnsService.exe not found after install. Run the installer by hand (it is in C:\ProgramData\CSL-Lab\downloads), then re-run this script.' }
# Technitium's installer is meant to fetch the ASP.NET Core runtime, but fails silently when
# it can't (e.g. behind a proxy); Technitium then cannot start at all.
$dotnet = (Get-Command dotnet.exe -ErrorAction SilentlyContinue).Source
# A console opened before .NET was installed doesn't have it on PATH yet.
if (-not $dotnet -and (Test-Path "$env:ProgramFiles\dotnet\dotnet.exe")) { $dotnet = "$env:ProgramFiles\dotnet\dotnet.exe" }
if (-not $dotnet -or
    -not ((Invoke-CslNative $dotnet @('--list-runtimes')).Output -match 'Microsoft\.AspNetCore\.App')) {
    throw ("No ASP.NET Core runtime is installed, so Technitium cannot start. Install the ASP.NET Core Runtime " +
           "Hosting Bundle (dotnet.microsoft.com/download/dotnet, Windows x64) for the .NET version Technitium needs: " +
           "the Application event log (source .NET Runtime, event 1023, for DnsService.exe) names the version and a download link. " +
           "Don't run DnsService.exe by hand to find out: see the README's Technitium section. Then re-run this script.")
}
Start-CslTechnitium -LabDir $LabDir

function ConvertTo-Plain([Security.SecureString]$s) {
    $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
}
$TechLog = Get-CslTechnitiumLog -LabDir $LabDir
$script:DnsToken = $null
$script:DnsPass = $null   # SecureString, kept so a restart of Technitium mid-setup only costs a re-login
function Invoke-Dns([string]$Path, [hashtable]$Body = @{}) {
    # Form POST keeps passwords and tokens out of URLs and logs. Technitium may exit and be
    # restarted by Windows at any time, so wait for it, retry, and log in again if the
    # restart dropped our session.
    for ($try = 1; ; $try++) {
        if (-not (Test-CslTechnitiumUp)) {
            Write-CslWarn 'Technitium is not answering (restarting?); waiting up to 2 minutes'
            $deadline = (Get-Date).AddSeconds(120)
            while (-not (Test-CslTechnitiumUp)) {
                if ((Get-Date) -gt $deadline) { throw "Technitium did not come back; see $TechLog" }
                Start-Sleep 2
            }
        }
        $b = @{} + $Body
        $h = @{}
        # Technitium 15+ takes the session token as a bearer header; older versions as a token parameter.
        if ($Path -ne 'user/login') { $b.token = $script:DnsToken; $h.Authorization = "Bearer $($script:DnsToken)" }
        try { $r = Invoke-RestMethod -Method Post -Uri "$api/$Path" -Body $b -Headers $h -UseBasicParsing -TimeoutSec 30 }
        catch { if ($try -lt 5) { Start-Sleep 3; continue }; throw }
        if ($r.status -eq 'invalid-token' -and $Path -ne 'user/login' -and $script:DnsPass -and $try -lt 5) { Connect-Dns; continue }
        if ($r.status -ne 'ok') { throw "Technitium $Path failed: $($r.status) $($r.errorMessage)" }
        return $r
    }
}
function Connect-Dns {
    $script:DnsToken = (Invoke-Dns 'user/login' @{ user = 'admin'; pass = (ConvertTo-Plain $script:DnsPass); includeInfo = 'false' }).token
}

# A fresh install's console login is admin / admin.
$script:DnsPass = ConvertTo-SecureString 'admin' -AsPlainText -Force
$isDefault = $true
try { Connect-Dns } catch { $isDefault = $false }
if ($isDefault) {
    Write-CslWarn 'Technitium still has its default admin password; choose a new one now.'
    do {
        $s1 = Read-Host 'New Technitium admin password' -AsSecureString
        $p1 = ConvertTo-Plain $s1
        $p2 = ConvertTo-Plain (Read-Host 'Repeat it' -AsSecureString)
        if ($p1 -ne $p2 -or $p1.Length -lt 8) { Write-CslWarn 'Passwords differ or are shorter than 8 characters.' }
    } until ($p1 -eq $p2 -and $p1.Length -ge 8)
    # Technitium 15+: pass = current password, newPass = new one (15.6.2: "Parameter 'newPass' missing" without it).
    Invoke-Dns 'user/changePassword' @{ pass = (ConvertTo-Plain $script:DnsPass); newPass = $p1 } | Out-Null
    $script:DnsPass = $s1
    $p1 = $p2 = $null
    Write-CslOk 'admin password changed (keep it with the kit, not in the image)'
} else {
    $script:DnsPass = Read-Host 'Technitium admin password' -AsSecureString
    Connect-Dns
}

$zones = @((Invoke-Dns 'zones/list').response.zones | ForEach-Object { $_.name })
function Add-Zone([string]$Zone, [System.Collections.IDictionary]$Records) {
    if ($zones -contains $Zone) { Write-CslOk "zone $Zone exists" }
    else { Invoke-Dns 'zones/create' @{ zone = $Zone; type = 'Primary' } | Out-Null; Write-CslOk "zone $Zone created" }
    foreach ($name in $Records.Keys) {
        $fqdn = "$name.$Zone"
        Invoke-Dns 'zones/records/add' @{ zone = $Zone; domain = $fqdn; type = 'A';
            ipAddress = $Records[$name]; ttl = '300'; overwrite = 'true' } | Out-Null
        Write-CslOk "  $fqdn A $($Records[$name])"
    }
}
Add-Zone 'csl.internal' ([ordered]@{ intranet = $LabIp; shop = $LabIp; bank = $LabIp; health = $LabIp; jobs = $LabIp })
if (-not $NoConnectivityZones) {
    # So Windows shows the cafe network as connected and pops up the Evil Portal sign-in.
    Add-Zone 'msftconnecttest.com' @{ www = $LabIp }
    Add-Zone 'msftncsi.com' @{ dns = '131.107.255.255' }
}
Invoke-Dns 'settings/set' @{ recursion = 'Deny' } | Out-Null
Write-CslOk 'recursion denied (there is no internet on the cafe network)'
Invoke-Dns 'user/logout' | Out-Null
$script:DnsToken = $script:DnsPass = $null

# ---------------------------------------------------------------- 5. firewall
Write-CslStep 'Firewall rules (inbound from 192.168.75.0/24 only)'
Get-NetFirewallRule -Group 'CSL Lab' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
New-NetFirewallRule -DisplayName 'CSL lab web'     -Group 'CSL Lab' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 80, 443 -RemoteAddress $LabNet | Out-Null
New-NetFirewallRule -DisplayName 'CSL lab DNS udp' -Group 'CSL Lab' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 53 -RemoteAddress $LabNet | Out-Null
New-NetFirewallRule -DisplayName 'CSL lab DNS tcp' -Group 'CSL Lab' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 53 -RemoteAddress $LabNet | Out-Null
# A rule naming caddy.exe stops Windows asking "allow access?" when Caddy first listens.
New-NetFirewallRule -DisplayName 'CSL lab caddy.exe' -Group 'CSL Lab' -Direction Inbound -Action Allow -Program $Caddy -RemoteAddress $LabNet | Out-Null
# Block overrides allow, and loopback is not filtered: the console stays usable at http://localhost:5380.
New-NetFirewallRule -DisplayName 'CSL lab block Technitium console' -Group 'CSL Lab' -Direction Inbound -Action Block -Protocol TCP -LocalPort 5380, 53443 | Out-Null
Write-CslOk 'web 80/443, DNS 53 from the lab subnet; Technitium console (5380) blocked from every network'
Repair-CslFirewall -CaddyPath $Caddy -LabNet $LabNet

# ---------------------------------------------------------------- done
Write-CslStep 'Staff image set up'
Write-Host @"
    Next:
      1. Serve the CA to the student image builds:  .\Setup-StaffImage.ps1 -ServeCert
         (or copy $PubCrt on a USB stick; its SHA-256 is $CertSha256)
      2. Plug in the router's USB-Ethernet adapter and test:  .\Start-StaffLab.ps1
         then  .\Start-StaffLab.ps1 -Stop
      3. Before capturing the image:  .\Cleanup-BeforeImage.ps1
"@
