# Shared helpers for the CSL Wireless Security lab image scripts.
# Windows PowerShell 5.1 (the version that ships with Windows 10).

Set-StrictMode -Version 2.0

$script:StateDir = Join-Path $env:ProgramData 'CSL-Lab'
$script:BaselineFile = Join-Path $script:StateDir 'accounts-baseline.json'

function Get-CslStateDir {
    if (-not (Test-Path $script:StateDir)) { New-Item -ItemType Directory -Path $script:StateDir | Out-Null }
    $script:StateDir
}

function Assert-CslAdmin {
    # 32-bit PowerShell on 64-bit Windows lacks Get-LocalUser and writes HKLM\SOFTWARE
    # policies to WOW6432Node, where Edge never reads them.
    if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
        throw 'This is 32-bit PowerShell. Use the 64-bit one: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe ("Windows PowerShell", not "(x86)").'
    }
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this script from an elevated PowerShell (Run as administrator).'
    }
}

function Write-CslStep([string]$Message) { Write-Host "`n==> $Message" -ForegroundColor Cyan }
function Write-CslOk([string]$Message)   { Write-Host "    OK   $Message" -ForegroundColor Green }
function Write-CslWarn([string]$Message) { Write-Host "    WARN $Message" -ForegroundColor Yellow }
function Write-CslFail([string]$Message) { Write-Host "    FAIL $Message" -ForegroundColor Red }

function Initialize-CslWeb {
    # PowerShell 5.1 defaults to TLS 1.0, which GitHub and most sites refuse.
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $global:ProgressPreference = 'SilentlyContinue'  # the progress bar makes downloads very slow
}

function Get-CslDownload {
    param([Parameter(Mandatory)][string]$Source, [Parameter(Mandatory)][string]$FileName)
    # $Source is a URL or a local path (for PCs without internet access).
    $dir = Join-Path (Get-CslStateDir) 'downloads'
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    $dest = Join-Path $dir $FileName
    if ($Source -match '^https?://') {
        Initialize-CslWeb
        Write-Host "    downloading $Source"
        Invoke-WebRequest -Uri $Source -OutFile $dest -UseBasicParsing
    } elseif ([IO.Path]::GetFullPath($Source) -ne [IO.Path]::GetFullPath($dest)) {
        Copy-Item -Path $Source -Destination $dest -Force
    }
    Unblock-File -Path $dest
    $dest
}

function Test-CslSignature {
    # Checks an installer's Authenticode signature. $SignerPattern matches the certificate subject.
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$SignerPattern)
    $sig = Get-AuthenticodeSignature -FilePath $Path
    if ($sig.Status -ne 'Valid') { throw "Signature on $Path is $($sig.Status); not running it." }
    if ($sig.SignerCertificate.Subject -notmatch $SignerPattern) {
        throw "Signature on $Path is from '$($sig.SignerCertificate.Subject)', expected '$SignerPattern'."
    }
    Write-CslOk "signature: $($sig.SignerCertificate.Subject)"
}

function Invoke-CslNative {
    # Runs a console program and returns its exit code and output as text. Windows
    # PowerShell 5.1 turns each stderr line into an error record, which stops a script
    # running with $ErrorActionPreference = 'Stop' even when the program succeeded
    # (Caddy logs everything to stderr), so only the exit code is used to judge success.
    param([Parameter(Mandatory)][string]$FilePath, [string[]]$Arguments = @())
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $out = @(& $FilePath @Arguments 2>&1 | ForEach-Object { "$_" })
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $old }
    [pscustomobject]@{ ExitCode = $code; Output = $out }
}

function Get-CslLocalUser {
    # Local accounts as Name, SID (string), Enabled, LastLogon. Uses Get-LocalUser where it
    # exists and falls back to WMI (LastLogon is then unknown).
    if (Get-Command Get-LocalUser -ErrorAction SilentlyContinue) {
        Get-LocalUser | ForEach-Object {
            [pscustomobject]@{ Name = $_.Name; SID = $_.SID.Value; Enabled = [bool]$_.Enabled; LastLogon = $_.LastLogon }
        }
    } else {
        Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' | ForEach-Object {
            [pscustomobject]@{ Name = $_.Name; SID = $_.SID; Enabled = -not $_.Disabled; LastLogon = $null }
        }
    }
}

function Remove-CslLocalUser {
    param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][string]$SID)
    if (Get-Command Remove-LocalUser -ErrorAction SilentlyContinue) { Remove-LocalUser -SID $SID }
    else {
        $r = Invoke-CslNative net.exe @('user', $Name, '/delete')
        if ($r.ExitCode -ne 0) { throw "net user $Name /delete failed: $($r.Output -join ' ')" }
    }
}

function Get-CslTechnitiumExe {
    # Technitium's DnsService.exe: from its service entry, else the usual install folders.
    $svc = Get-CimInstance Win32_Service -Filter "Name='DnsService'" -ErrorAction SilentlyContinue
    if ($svc -and $svc.PathName) {
        $p = ($svc.PathName -replace '^\s*"([^"]+)".*$', '$1')
        if (Test-Path $p) { return $p }
    }
    foreach ($d in "${env:ProgramFiles(x86)}\Technitium", "$env:ProgramFiles\Technitium") {
        $f = Get-ChildItem $d -Recurse -Filter DnsService.exe -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($f) { return $f.FullName }
    }
    $null
}

function Test-CslTechnitiumUp {
    $tcp = New-Object Net.Sockets.TcpClient
    try { $tcp.Connect('127.0.0.1', 5380); $true } catch { $false } finally { $tcp.Close() }
}

function Get-CslTechnitiumDataDir {
    # The data folder the DnsService service is started with (config, zones, logs).
    $svc = Get-CimInstance Win32_Service -Filter "Name='DnsService'" -ErrorAction SilentlyContinue
    if ($svc -and $svc.PathName -match '^\s*"[^"]+"\s+"([^"]+)"') { return [Environment]::ExpandEnvironmentVariables($Matches[1]) }
    Join-Path $env:ProgramData 'Technitium DNS Server'
}

function Get-CslTechnitiumLog {
    # Technitium's own log for today: one file per UTC day in <data folder>\logs.
    param([string]$LabDir = 'C:\csl-lab')   # not used; kept so existing callers still work
    Join-Path (Get-CslTechnitiumDataDir) ('logs\{0}.log' -f (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd'))
}

function Get-CslTechnitiumStray {
    # DnsService.exe processes the service did not start: copies run by hand, or one left
    # behind by a crashed service. They hold ports 53/5380, and a copy run as an
    # administrator creates files in the data folder that the service account can only read.
    $svcPid = (Get-CimInstance Win32_Service -Filter "Name='DnsService'" -ErrorAction SilentlyContinue).ProcessId
    @(Get-CimInstance Win32_Process -Filter "Name='DnsService.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessId -ne $svcPid })
}

function Start-CslTechnitium {
    # Runs Technitium as its DnsService Windows service: automatic start, restart on failure.
    # On the first staff PC the service crash-looped (Running, PID changing, no ports open)
    # because copies of DnsService.exe run by hand as an administrator had created files in
    # its data folder (C:\ProgramData\Technitium DNS Server) that the service account,
    # NT SERVICE\DnsService, may only read: it died with UnauthorizedAccessException on
    # logs\<date>.log. Giving that account Modify on its data folder fixed it.
    param([string]$LabDir = 'C:\csl-lab')
    $svc = Get-Service DnsService -ErrorAction SilentlyContinue
    if (-not $svc) { throw 'The DnsService Windows service (Technitium) is not installed.' }
    # Leftovers of the console-mode runner from kit version df65ad4.
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*csl-technitium-runner.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Remove-Item (Join-Path $LabDir 'csl-technitium-runner.ps1') -Force -ErrorAction SilentlyContinue
    foreach ($p in Get-CslTechnitiumStray) {
        Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        Write-CslWarn "stopped a DnsService.exe that the service did not start (PID $($p.ProcessId))"
    }
    $data = Get-CslTechnitiumDataDir
    if (-not (Test-Path $data)) { New-Item -ItemType Directory -Path $data | Out-Null }
    $r = Invoke-CslNative icacls.exe @($data, '/grant', 'NT SERVICE\DnsService:(OI)(CI)M')
    if ($r.ExitCode -ne 0) { throw "icacls on $data failed: $($r.Output -join ' ')" }
    if ($svc.StartType -ne 'Automatic') { Set-Service DnsService -StartupType Automatic }
    # Windows' default is to leave a crashed service stopped.
    Invoke-CslNative sc.exe @('failure', 'DnsService', 'reset=', '86400', 'actions=', 'restart/5000/restart/5000/restart/60000') | Out-Null
    Write-CslOk "DnsService: automatic start, restarts on failure, NT SERVICE\DnsService may modify $data"
    $t0 = Get-Date
    if ((Get-Service DnsService).Status -ne 'Running') {
        # sc.exe returns at once; Start-Service can wait a long time on a service that hangs.
        Invoke-CslNative sc.exe @('start', 'DnsService') | Out-Null
    }
    Write-Host '    waiting for the Technitium console on 127.0.0.1:5380 (first start can take a minute)'
    $deadline = (Get-Date).AddSeconds(120)
    while (-not (Test-CslTechnitiumUp)) {
        if ((Get-Date) -gt $deadline) {
            $ev = Get-WinEvent -FilterHashtable @{ LogName = 'Application'; StartTime = $t0; Level = 1, 2 } -ErrorAction SilentlyContinue |
                Where-Object { $_.Message -match 'DnsService' } | Select-Object -First 1
            $why = if ($ev) { $ev.Message -replace '\s+', ' ' } else { 'no DnsService error in the Application event log' }
            throw "Technitium not answering on 127.0.0.1:5380 after 2 minutes (service $((Get-Service DnsService).Status)): $($why.Substring(0, [Math]::Min(700, $why.Length)))"
        }
        Start-Sleep 3
    }
    Write-CslOk 'Technitium console answering on 127.0.0.1:5380'
}

function Stop-CslTechnitium {
    # Stops the DnsService service (it starts again at boot) and any stray copies.
    $svc = Get-Service DnsService -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -ne 'Stopped') {
        # Stop-Service can wait forever on a stuck service: ask once, then kill after 10 s.
        # (A killed service counts as a failure, so Windows restarts it after 5 s.)
        Invoke-CslNative sc.exe @('stop', 'DnsService') | Out-Null
        $deadline = (Get-Date).AddSeconds(10)
        while ((Get-Service DnsService).Status -ne 'Stopped' -and (Get-Date) -lt $deadline) { Start-Sleep 1 }
        $svcPid = (Get-CimInstance Win32_Service -Filter "Name='DnsService'").ProcessId
        if ($svcPid) { Stop-Process -Id $svcPid -Force -ErrorAction SilentlyContinue; Write-CslWarn 'DnsService did not stop within 10 s; killed it' }
    }
    foreach ($p in Get-CslTechnitiumStray) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
    Write-CslOk 'Technitium stopped (the DnsService service starts again at boot)'
}

function Get-CslCertSha256 {
    param([Parameter(Mandatory)][Security.Cryptography.X509Certificates.X509Certificate2]$Certificate)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { ($sha.ComputeHash($Certificate.RawData) | ForEach-Object { $_.ToString('X2') }) -join '' }
    finally { $sha.Dispose() }
}

function Get-CslAccountSnapshot {
    $admins = @()
    try {
        $admins = @(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | ForEach-Object { $_.Name })
    } catch {
        # Missing cmdlet, or orphaned domain SIDs in the group: fall back to net.exe.
        # The group is named by SID because its name is translated on non-English Windows.
        $grp = (New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')).Translate([Security.Principal.NTAccount]).Value.Split('\')[-1]
        $admins = @((Invoke-CslNative net.exe @('localgroup', $grp)).Output | Select-Object -Skip 6 |
            Where-Object { $_ -and $_ -notmatch 'command completed' })
    }
    [pscustomobject]@{
        Taken          = (Get-Date).ToString('s')
        Users          = @(Get-CslLocalUser | ForEach-Object { $_.Name })
        Administrators = $admins
    }
}

function Save-CslAccountBaseline {
    # Records the local accounts and Administrators members the first time any setup
    # script runs, so Cleanup-BeforeImage.ps1 can remove anything added afterwards.
    Get-CslStateDir | Out-Null
    if (Test-Path $script:BaselineFile) {
        $b = Get-Content $script:BaselineFile -Raw | ConvertFrom-Json
        Write-CslOk "account baseline already recorded ($($b.Taken)); keeping it"
        return
    }
    Get-CslAccountSnapshot | ConvertTo-Json | Set-Content -Path $script:BaselineFile -Encoding UTF8
    Write-CslOk "recorded the current local accounts in $script:BaselineFile"
}

function Get-CslAccountBaseline {
    if (-not (Test-Path $script:BaselineFile)) { return $null }
    Get-Content $script:BaselineFile -Raw | ConvertFrom-Json
}

function Repair-CslFirewall {
    # Keeps caddy.exe and Technitium reachable from the cafe network only.
    # Windows' "allow access?" prompt makes program-wide rules: Allow opens the program to
    # every network on that profile, and Cancel adds a Block rule that overrides our allow
    # rules. This removes such Block rules and narrows other Allow rules to the lab subnet.
    param([Parameter(Mandatory)][string]$CaddyPath, [string]$LabNet = '192.168.75.0/24')
    $apps = @{}
    Get-NetFirewallApplicationFilter -All | ForEach-Object { $apps[$_.InstanceID] = $_.Program }
    $changed = 0
    Get-NetFirewallRule -Direction Inbound | Where-Object { $_.Group -notlike 'CSL Lab*' } | ForEach-Object {
        $r = $_
        $prog = [string]$apps[$r.Name]
        $isCaddy = $prog -and ($prog -ieq $CaddyPath -or $prog -like '*\caddy.exe')
        $isTech  = ($prog -like '*Technitium*') -or ($r.DisplayName -match 'Technitium|DnsServerApp')
        if (-not ($isCaddy -or $isTech)) { return }
        if ($r.Action -eq 'Block') {
            Remove-NetFirewallRule -Name $r.Name
            Write-CslWarn "removed block rule '$($r.DisplayName)' (from Cancel on a firewall prompt)"
            $changed++
        } elseif ($r.Enabled -eq 'True') {
            $remote = @(($r | Get-NetFirewallAddressFilter).RemoteAddress) -join ','
            if ($remote -notmatch '^192\.168\.75\.0') {
                Set-NetFirewallRule -Name $r.Name -RemoteAddress $LabNet
                Write-CslWarn "narrowed '$($r.DisplayName)' from '$remote' to $LabNet"
                $changed++
            }
        }
    }
    if (-not $changed) { Write-CslOk 'no program-wide caddy/Technitium firewall rules to fix' }
}

Export-ModuleMember -Function *-Csl*
