<#
.SYNOPSIS
  On the day: puts the staff PC on the cafe network and starts the lab web servers.

.DESCRIPTION
  Run elevated on the staff PC with the router plugged into the USB-Ethernet adapter. It:
    1. gives the lab adapter 192.168.75.10 and .11 (no gateway, so the PC's own
       internet still goes through the university NIC);
    2. starts Technitium (its DnsService Windows service), both Caddy instances and the
       attacker server's credential logger (csl-cred-logger.ps1), each of those three in a
       minimised window (closing a window stops that server; re-run this script). Each run
       starts a new, empty sites\fake-shop\inputs.txt;
    3. checks the router, DNS and every site, and prints PASS/FAIL for each.
  -Stop stops Caddy and Technitium, removes the addresses and returns the adapter to DHCP.
  -Test only runs the checks.

.EXAMPLE
  .\Start-StaffLab.ps1                      # picks the adapter, or asks
  .\Start-StaffLab.ps1 -Adapter 'Ethernet 2'
  .\Start-StaffLab.ps1 -Stop
#>
[CmdletBinding(DefaultParameterSetName = 'Start')]
param(
    [string]$Adapter,
    # The two rooms' routers: 192.168.75.1 and 192.168.75.254 (as on their stickers). The check
    # passes if any of these answers.
    [string[]]$RouterIp = @('192.168.75.1', '192.168.75.254'),
    [Parameter(ParameterSetName = 'Stop')][switch]$Stop,
    [Parameter(ParameterSetName = 'Test')][switch]$Test,
    [string]$LabDir = 'C:\csl-lab'
)

$ErrorActionPreference = 'Stop'
# $PSScriptRoot is empty in some hosts (ISE, F8 selections, some PS 5.1 launchers).
$ScriptDir = if ($PSScriptRoot) { $PSScriptRoot }
             elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path }
             else { (Get-Location).Path }
if (-not (Test-Path (Join-Path $ScriptDir 'CslLab.Common.psm1'))) {
    throw "CslLab.Common.psm1 not found in '$ScriptDir'. cd into the kit's windows folder and run: powershell -ExecutionPolicy Bypass -File .\<script>.ps1"
}
Import-Module (Join-Path $ScriptDir 'CslLab.Common.psm1') -Force
Assert-CslAdmin

$Caddy = Join-Path $LabDir 'caddy.exe'
$Ips = '192.168.75.10', '192.168.75.11'

function Select-LabAdapter {
    if ($Adapter) { return Get-NetAdapter -Name $Adapter }
    # The adapter that already has a lab address, else an up adapter with no default gateway.
    $withIp = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $Ips -contains $_.IPAddress } | Select-Object -First 1
    if ($withIp) { return Get-NetAdapter -InterfaceIndex $withIp.InterfaceIndex }
    $gw = @(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | ForEach-Object { $_.InterfaceIndex })
    $cand = @(Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' -and $gw -notcontains $_.ifIndex })
    if ($cand.Count -eq 1) { return $cand[0] }
    $all = @(Get-NetAdapter -Physical | Sort-Object Name)
    Write-Host 'Which adapter is plugged into the cafe router?'
    for ($i = 0; $i -lt $all.Count; $i++) {
        $a = $all[$i]
        $note = if ($gw -contains $a.ifIndex) { '(has the default route: probably the university NIC)' } else { '' }
        Write-Host ("  [{0}] {1}  {2}  {3}  {4}" -f $i, $a.Name, $a.InterfaceDescription, $a.Status, $note)
    }
    $n = [int](Read-Host 'Number')
    $all[$n]
}

function Stop-LabCaddy {
    Get-Process caddy -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Caddy } | Stop-Process -Force
    # The attacker server's credential logger (csl-cred-logger.ps1) goes with it.
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*csl-cred-logger.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

function Invoke-LabChecks {
    Write-CslStep 'Checks'
    $script:fails = 0
    function Check([string]$Name, [scriptblock]$Body) {
        try { $msg = & $Body; Write-CslOk "$Name $msg" }
        catch { Write-CslFail "$Name : $($_.Exception.Message)"; $script:fails++ }
    }
    Check "router ($($RouterIp -join ' or ')) answers ping" {
        $hit = @($RouterIp | Where-Object { Test-Connection $_ -Count 2 -Quiet })
        if (-not $hit) { throw 'no reply (cable or Wi-Fi to the router? router LAN IP?)' }
        "-> $($hit -join ', ')"
    }
    foreach ($h in 'intranet', 'shop', 'bank', 'health', 'jobs') {
        Check "DNS $h.csl.internal" {
            $r = Resolve-DnsName "$h.csl.internal" -Server 192.168.75.10 -Type A -DnsOnly -QuickTimeout
            $ip = ($r | Where-Object { $_.Type -eq 'A' }).IPAddress
            if ($ip -ne '192.168.75.10') { throw "resolved to '$ip'" }
            "-> $ip"
        }
    }
    Check 'DNS recursion refused (example.com)' {
        # Only a "refused" answer counts: a timeout means DNS isn't answering at all.
        try { Resolve-DnsName example.com -Server 192.168.75.10 -DnsOnly -QuickTimeout -ErrorAction Stop | Out-Null }
        catch { if ($_.Exception.Message -match 'refused') { return }; throw "no refusal, DNS didn't answer: $($_.Exception.Message)" }
        throw 'example.com resolved: recursion is on'
    }
    # curl.exe ships with Windows 10 1803+. --resolve pins each name to the lab IP, so the
    # checks do not depend on this PC's own DNS settings. -k because this PC does not trust
    # the lab CA (only the student image does).
    function Web([string]$Url, [string]$Ip, [int]$Port) {
        $host_ = ([uri]$Url).Host
        $r = Invoke-CslNative curl.exe @('-sk', '-o', 'NUL', '-D', '-', '--max-time', '5', '--resolve', "${host_}:${Port}:$Ip", $Url)
        if ($r.ExitCode -ne 0) { throw "curl exit $($r.ExitCode) (is Caddy running?)" }
        $r.Output -join "`n"
    }
    Check 'http://intranet  200' { $h = Web 'http://intranet.csl.internal/' 192.168.75.10 80; if ($h -notmatch '^HTTP/\S+ 200') { throw ($h -split "`n")[0] } }
    Check 'http://bank      301 -> https' { $h = Web 'http://bank.csl.internal/' 192.168.75.10 80; if ($h -notmatch '^HTTP/\S+ 301') { throw ($h -split "`n")[0] } }
    Check 'https://bank     200 + HSTS' { $h = Web 'https://bank.csl.internal/' 192.168.75.10 443; if ($h -notmatch '^HTTP/\S+ 200' -or $h -notmatch '(?im)^strict-transport-security:') { throw 'no 200 or no HSTS header' } }
    Check 'http://shop      302 -> https' { $h = Web 'http://shop.csl.internal/' 192.168.75.10 80; if ($h -notmatch '^HTTP/\S+ 302') { throw ($h -split "`n")[0] } }
    Check 'https://shop     200, no HSTS' { $h = Web 'https://shop.csl.internal/' 192.168.75.10 443; if ($h -notmatch '^HTTP/\S+ 200' -or $h -match '(?im)^strict-transport-security:') { throw 'no 200, or HSTS present' } }
    Check 'https://health   200' { $h = Web 'https://health.csl.internal/' 192.168.75.10 443; if ($h -notmatch '^HTTP/\S+ 200') { throw ($h -split "`n")[0] } }
    Check 'https://jobs     200' { $h = Web 'https://jobs.csl.internal/' 192.168.75.10 443; if ($h -notmatch '^HTTP/\S+ 200') { throw ($h -split "`n")[0] } }
    Check 'attacker http (.11) 200' { $h = Web 'http://shop.csl.internal/' 192.168.75.11 80; if ($h -notmatch '^HTTP/\S+ 200') { throw ($h -split "`n")[0] } }
    Check 'attacker credential logger (127.0.0.1:8099)' {
        $t = New-Object Net.Sockets.TcpClient
        try { if (-not $t.ConnectAsync('127.0.0.1', 8099).Wait(2000)) { throw 'not listening (logger window closed?)' } } finally { $t.Close() }
    }
    Check 'attacker inputs.txt (.11) 200' { $h = Web 'http://shop.csl.internal/inputs.txt' 192.168.75.11 80; if ($h -notmatch '^HTTP/\S+ 200') { throw ($h -split "`n")[0] } }
    Check 'attacker https bank (.11)' { $h = Web 'https://bank.csl.internal/' 192.168.75.11 443; if ($h -notmatch '^HTTP/\S+ 200') { throw ($h -split "`n")[0] } }
    Write-Host ''
    if ($script:fails) { Write-CslFail "$($script:fails) check(s) failed" } else { Write-CslOk 'all checks passed. Next: join CSL-Cafe from a student PC and open the favourites.' }
}

if ($Test) { Invoke-LabChecks; return }

$nic = Select-LabAdapter
if (-not $nic) { throw 'No lab adapter selected.' }

if ($Stop) {
    Write-CslStep "Stopping the lab on '$($nic.Name)'"
    Stop-LabCaddy
    Write-CslOk 'Caddy stopped'
    Stop-CslTechnitium
    Get-NetIPAddress -InterfaceIndex $nic.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $Ips -contains $_.IPAddress } | Remove-NetIPAddress -Confirm:$false
    Set-NetIPInterface -InterfaceIndex $nic.ifIndex -AddressFamily IPv4 -Dhcp Enabled
    Write-CslOk 'lab addresses removed, adapter back on DHCP'
    return
}

Write-CslStep "Lab addresses on '$($nic.Name)' ($($nic.InterfaceDescription))"
if ($nic.Status -ne 'Up') {
    # Windows will not take static addresses on a disconnected adapter (on Wi-Fi it fails with
    # "Inconsistent parameters PolicyStore PersistentStore and Dhcp Enabled").
    $hint = if ("$($nic.PhysicalMediaType)" -match '802\.11') { "connect this Wi-Fi adapter to the router's network first" } else { 'is the cable to the router plugged in and the router on?' }
    throw "Adapter '$($nic.Name)' is $($nic.Status): $hint"
}
# -ErrorAction Stop: these cmdlets live in a module, so they don't see this script's
# $ErrorActionPreference, and their errors would otherwise not stop the script.
Set-NetIPInterface -InterfaceIndex $nic.ifIndex -AddressFamily IPv4 -Dhcp Disabled -ErrorAction Stop
$have = @(Get-NetIPAddress -InterfaceIndex $nic.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.IPAddress })
foreach ($ip in $Ips) {
    if ($have -contains $ip) { Write-CslOk "$ip already set"; continue }
    New-NetIPAddress -InterfaceIndex $nic.ifIndex -IPAddress $ip -PrefixLength 24 -ErrorAction Stop | Out-Null   # no -DefaultGateway on purpose
    Write-CslOk "$ip/24"
}
$have = @(Get-NetIPAddress -InterfaceIndex $nic.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.IPAddress })
foreach ($ip in $Ips) { if ($have -notcontains $ip) { throw "$ip is not on '$($nic.Name)' after setting it" } }
# Wait for duplicate address detection, or Caddy cannot bind.
$deadline = (Get-Date).AddSeconds(20)
while ((Get-NetIPAddress -InterfaceIndex $nic.ifIndex -AddressFamily IPv4 | Where-Object { $Ips -contains $_.IPAddress -and $_.AddressState -ne 'Preferred' }) -and (Get-Date) -lt $deadline) { Start-Sleep 1 }

Write-CslStep 'Services'
Start-CslTechnitium -LabDir $LabDir
Stop-LabCaddy
foreach ($cfg in 'Caddyfile', 'Caddyfile.attacker') {
    Start-Process -FilePath $Caddy -WorkingDirectory $LabDir -WindowStyle Minimized `
        -ArgumentList 'run', '--adapter', 'caddyfile', '--config', "`"$(Join-Path $LabDir $cfg)`""
    Write-CslOk "caddy $cfg started (minimised window; closing it stops that server)"
}
# Part 5: the attacker server's credential logger. A new list for each session.
$inputs = Join-Path $LabDir 'sites\fake-shop\inputs.txt'
Remove-Item $inputs -Force -ErrorAction SilentlyContinue
Start-Process powershell.exe -WindowStyle Minimized -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass',
    '-File', "`"$(Join-Path $ScriptDir 'csl-cred-logger.ps1')`"", '-OutFile', "`"$inputs`""
Write-CslOk "credential logger started (minimised window); new, empty $inputs"
Start-Sleep -Seconds 5
Write-CslStep 'Firewall'
Repair-CslFirewall -CaddyPath $Caddy
Invoke-LabChecks
